﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Eproject.Migrations
{
    /// <inheritdoc />
    public partial class DeleteSurvey1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Surveys_SurveyId",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "SurveyId",
                table: "AspNetUsers",
                newName: "SId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_SurveyId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_SId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Surveys_SId",
                table: "AspNetUsers",
                column: "SId",
                principalTable: "Surveys",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Surveys_SId",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "SId",
                table: "AspNetUsers",
                newName: "SurveyId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_SId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_SurveyId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Surveys_SurveyId",
                table: "AspNetUsers",
                column: "SurveyId",
                principalTable: "Surveys",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
